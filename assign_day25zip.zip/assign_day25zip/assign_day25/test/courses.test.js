const { expect } = require("chai");
const courses = require("../src/data/coursesData");
const {
  getAllCourses,
  getCourseById
} = require("../src/controllers/coursesController");

function mockRes() {
  return {
    statusCode: 200,
    body: null,
    status(code) {
      this.statusCode = code;
      return this;
    },
    json(data) {
      this.body = data;
      return this;
    }
  };
}

describe("Courses Controller Tests", () => {
  it("GET all courses", () => {
    const req = {};
    const res = mockRes();

    getAllCourses(req, res);

    expect(res.statusCode).to.equal(200);
    expect(res.body.length).to.equal(courses.length);
  });

  it("GET course by ID", () => {
    const req = { params: { id: "1" } };
    const res = mockRes();

    getCourseById(req, res);

    expect(res.statusCode).to.equal(200);
    expect(res.body.id).to.equal(1);
  });

  it("invalid ID returns 404", () => {
    const req = { params: { id: "999" } };
    const res = mockRes();

    getCourseById(req, res);

    expect(res.statusCode).to.equal(404);
  });
});
