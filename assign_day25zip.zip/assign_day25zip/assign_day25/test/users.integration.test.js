const request = require("supertest");
const { expect } = require("chai");
const app = require("../src/app");

describe("Users API Integration Tests", () => {

  it("GET /api/users", async () => {
    const res = await request(app).get("/api/users");
    expect(res.status).to.equal(200);
  });

  it("POST /api/users", async () => {
    const res = await request(app)
      .post("/api/users")
      .send({ name: "Charlie", email: "charlie@example.com" });

    expect(res.status).to.equal(201);
    expect(res.body.name).to.equal("Charlie");
  });

  it("POST invalid user returns 400", async () => {
    const res = await request(app).post("/api/users").send({ name: "" });
    expect(res.status).to.equal(400);
  });

});
