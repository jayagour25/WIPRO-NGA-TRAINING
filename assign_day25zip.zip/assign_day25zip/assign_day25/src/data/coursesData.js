const courses = [
  { id: 1, title: "JavaScript Basics", level: "Beginner" },
  { id: 2, title: "Advanced React", level: "Intermediate" },
  { id: 3, title: "Node.js & APIs", level: "Intermediate" }
];

module.exports = courses;
