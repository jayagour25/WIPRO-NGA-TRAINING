export default function FadeWrapper({ children }) {
  return <div className="fade">{children}</div>;
}
