export default function Message({ render }) {
  return <div>{render()}</div>;
}
