export default function InstructorProfile() {
  return (
    <div className="card p-3 mt-3">
      <h3>Instructor Profile</h3>
      <p>Instructor: John Doe (Senior React Developer)</p>
    </div>
  );
}
