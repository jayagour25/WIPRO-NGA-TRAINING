export default function CourseDetails() {
  return (
    <div className="card p-3 mt-3">
      <h3>Course Details</h3>
      <p>This course covers advanced React concepts like lazy loading, portals, and pure components.</p>
    </div>
  );
}
