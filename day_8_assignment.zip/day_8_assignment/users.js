db.Users.insertMany([
  {
   
    "name": "vishu",
    "email": "vishu@example.com",
    "joinDate": ISODate("2023-06-15T00:00:00Z")
  },
  {
 
    "name": "yash",
    "email": "yash@example.com",
    "joinDate": ISODate("2024-01-10T00:00:00Z")
  },
  {

    "name": "harsh",
    "email": "harsh@example.com",
    "joinDate": ISODate("2024-09-05T00:00:00Z")
  }
]
);